#!/bin/bash
git checkout main
git merge new-feature

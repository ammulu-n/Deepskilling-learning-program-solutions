#!/bin/bash
git init
echo 'Hello Git HOL 1' > file1.txt
git add file1.txt
git commit -m 'Initial commit with file1.txt'

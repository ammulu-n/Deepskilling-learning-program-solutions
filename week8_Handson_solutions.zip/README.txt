Week 8 Git HOL Solutions
========================

Git-HOL-1: Initialize repo, add and commit a file.
Git-HOL-2: Create and switch to a new branch, add a file, commit.
Git-HOL-3: Merge feature branch into main.
Git-HOL-4: Show git log in a concise graphical form.
Git-HOL-5: Add remote and show remotes.

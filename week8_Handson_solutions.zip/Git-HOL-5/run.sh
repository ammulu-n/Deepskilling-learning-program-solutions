#!/bin/bash
git remote add origin https://example.com/fake-repo.git
git remote -v

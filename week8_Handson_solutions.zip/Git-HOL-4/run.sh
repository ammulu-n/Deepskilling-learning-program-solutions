#!/bin/bash
git log --oneline --graph --all

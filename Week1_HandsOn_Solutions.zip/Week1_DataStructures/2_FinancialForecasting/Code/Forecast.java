public class Forecast {

    /**
     * Recursive method to compute future value with constant growth rate.
     *
     * @param present       current value
     * @param annualGrowth  growth rate (e.g., 0.05 for 5%)
     * @param years         number of years into the future
     * @return future value
     */
    public static double futureValue(double present, double annualGrowth, int years) {
        if (years == 0) return present;
        return futureValue(present * (1 + annualGrowth), annualGrowth, years - 1);
    }

    public static void main(String[] args) {
        double pv = 1000.0;
        double rate = 0.07;   // 7% growth
        int yrs = 8;

        double fv = futureValue(pv, rate, yrs);
        System.out.printf("Future value after %d years = %.2f%n", yrs, fv);
    }
}

import java.util.Arrays;
import java.util.Comparator;

public class SearchAlgorithms {

    // Linear Search
    public static int linearSearch(Product[] arr, int targetId) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i].id == targetId) return i;
        }
        return -1;
    }

    // Binary Search (requires sorted array)
    public static int binarySearch(Product[] arr, int targetId) {
        int left = 0, right = arr.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            if (arr[mid].id == targetId) return mid;
            if (arr[mid].id < targetId)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return -1;
    }

    public static void main(String[] args) {
        Product[] catalogue = {
                new Product(105, "Watch", "Accessories"),
                new Product(101, "Laptop", "Electronics"),
                new Product(103, "Shoes", "Apparel"),
                new Product(102, "Phone", "Electronics")
        };

        // Linear search on unsorted array
        int idx = linearSearch(catalogue, 103);
        System.out.println("Linear Search index for ID 103 = " + idx);

        // Sort by id for binary search
        Arrays.sort(catalogue, Comparator.comparingInt(p -> p.id));

        idx = binarySearch(catalogue, 103);
        System.out.println("Binary Search index for ID 103 = " + idx);
    }
}

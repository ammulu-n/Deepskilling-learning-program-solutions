public class FactoryDemo {
    public static void main(String[] args) {
        // Choosing factory at runtime
        DocumentFactory factory = new WordDocumentFactory();
        Document doc = factory.createDocument();
        doc.open(); // Word

        factory = new PdfDocumentFactory();
        doc = factory.createDocument();
        doc.open(); // PDF

        factory = new ExcelDocumentFactory();
        doc = factory.createDocument();
        doc.open(); // Excel
    }
}

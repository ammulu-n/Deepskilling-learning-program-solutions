/**
 * Product interface
 */
public interface Document {
    void open();
}

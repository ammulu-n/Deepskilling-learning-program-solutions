/**
 * Test class to verify Singleton behaviour of Logger.
 */
public class SingletonDemo {
    public static void main(String[] args) {
        Logger first = Logger.getInstance();
        Logger second = Logger.getInstance();

        first.log("Hello, Singleton!");
        System.out.println("Are both references same? " + (first == second));
    }
}

/**
 * Singleton Logger class ensures only one instance exists.
 */
public class Logger {
    // static variable to hold single instance
    private static Logger instance;

    // private constructor prevents external instantiation
    private Logger() { }

    /**
     * Global access point. Thread‑safe using synchronized.
     */
    public static synchronized Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    public void log(String message) {
        System.out.println("[LOG] " + message);
    }
}

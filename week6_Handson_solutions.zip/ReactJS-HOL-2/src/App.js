import React from 'react';
function Header() {
  return <h2>This is the Header</h2>;
}
function Footer() {
  return <h4>This is the Footer</h4>;
}
export default function App() {
  return (
    <div>
      <Header />
      <p>Main content goes here.</p>
      <Footer />
    </div>
  );
}
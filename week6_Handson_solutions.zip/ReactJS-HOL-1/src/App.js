import React from 'react';
export default function App() {
  return <h1>Hello, Week 6 React HOL 1!</h1>;
}
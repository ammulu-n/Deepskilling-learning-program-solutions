import React from 'react';
function UserCard({ name, age }) {
  return <p>{name} is {age} years old.</p>;
}
export default function App() {
  return (
    <div>
      <UserCard name="Alice" age={25} />
      <UserCard name="Bob" age={30} />
    </div>
  );
}
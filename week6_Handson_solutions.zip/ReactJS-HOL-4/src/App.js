import React, { useState } from 'react';
export default function App() {
  const [visible, setVisible] = useState(true);
  return (
    <div>
      {visible && <p>This is visible text.</p>}
      <button onClick={() => setVisible(!visible)}>Toggle</button>
    </div>
  );
}
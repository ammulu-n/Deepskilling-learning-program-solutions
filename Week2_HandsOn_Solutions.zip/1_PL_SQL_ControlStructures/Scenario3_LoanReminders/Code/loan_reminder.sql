-- Scenario 3: Send loan reminders
BEGIN
    FOR loan IN (SELECT CustomerID, DueDate FROM Loans WHERE DueDate <= SYSDATE + 30) LOOP
        DBMS_OUTPUT.PUT_LINE('Reminder: Loan due soon for Customer ' || loan.CustomerID);
    END LOOP;
END;
/

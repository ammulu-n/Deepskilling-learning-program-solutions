public class TestSetup {
    public int add(int a, int b) {
        return a + b;
    }
}

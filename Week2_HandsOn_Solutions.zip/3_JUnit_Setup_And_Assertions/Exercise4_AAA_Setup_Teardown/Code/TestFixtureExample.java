import org.junit.jupiter.api.*;

public class TestFixtureExample {

    @BeforeEach
    void setup() {
        System.out.println("Setup before each test");
    }

    @AfterEach
    void teardown() {
        System.out.println("Teardown after each test");
    }

    @Test
    void testBusinessLogic() {
        int result = 2 + 2;
        Assertions.assertEquals(4, result);
    }
}

package com.example.loanservice;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/loans")
public class LoanController {

    @GetMapping("/{customerId}")
    public String getLoan(@PathVariable String customerId) {
        return "Loan details for customer: " + customerId;
    }
}
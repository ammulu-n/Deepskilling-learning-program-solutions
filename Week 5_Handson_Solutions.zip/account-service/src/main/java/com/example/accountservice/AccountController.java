package com.example.accountservice;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @GetMapping("/{customerId}")
    public String getAccount(@PathVariable String customerId) {
        return "Account details for customer: " + customerId;
    }
}